(function() {
  var app;

  app = angular.module('alephBank', []);

  app.controller('newTransferController', function($scope) {
    return $scope.data = gon.x;
  });

  app.controller('historyController', function($scope) {});

  app.controller('helpController', function($scope) {});

}).call(this);
